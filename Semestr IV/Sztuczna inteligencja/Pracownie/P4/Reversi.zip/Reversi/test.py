import numpy as np
import matplotlib.pyplot as plt
from queue import PriorityQueue

if __name__ == '__main__':
    print(np.hstack([np.zeros((3,3)),np.zeros((3,3))]))