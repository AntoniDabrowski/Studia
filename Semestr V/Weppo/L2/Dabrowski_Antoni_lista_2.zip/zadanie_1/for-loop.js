let total = 0
let limit = 10
for (let i=0;i<limit;i+=1){
    total+=i
}
console.log(total)