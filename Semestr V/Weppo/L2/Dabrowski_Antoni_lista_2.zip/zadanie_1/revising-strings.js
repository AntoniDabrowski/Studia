const pizza = 'pizza is alright'
console.log(pizza.replace('alright','wonderful'))