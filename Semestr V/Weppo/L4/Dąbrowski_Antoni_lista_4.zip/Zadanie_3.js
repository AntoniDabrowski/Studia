

exports.item = "Hello"

console.log(require('./Zadanie_3a.js'))