

exports.z3 = "z3"

// console.log(require('./Zadanie_3.js'))

// To nie może działać. Procedura wykonania jest następująca:
//      1. wykonaj kod w pliku Zadanie_3.js
//      2. aby to wykonać, należy wykonać najpierw kod z pliku Zadanie_3a.js
//      ...