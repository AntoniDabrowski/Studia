List2\_ex2\_Dabrowski module
============================

.. automodule:: List2_ex2_Dabrowski
   :members:
   :undoc-members:
   :show-inheritance:
