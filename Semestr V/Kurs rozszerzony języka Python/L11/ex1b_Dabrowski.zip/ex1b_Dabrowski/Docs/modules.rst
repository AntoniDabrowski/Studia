ex1b_Dabrowski
==============

.. toctree::
   :maxdepth: 4

   List3_ex2_Dabrowski
